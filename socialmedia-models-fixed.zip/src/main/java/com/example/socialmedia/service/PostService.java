package com.example.socialmedia.service;

import com.example.socialmedia.model.Post;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PostService {
    private final List<Post> posts = new ArrayList<>();

    public List<Post> getAllPosts() {
        return posts;
    }

    public Post savePost(Post post) {
        posts.add(post);
        return post;
    }
}
