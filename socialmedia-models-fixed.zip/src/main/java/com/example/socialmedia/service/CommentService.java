package com.example.socialmedia.service;

import com.example.socialmedia.model.Comment;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CommentService {
    private final List<Comment> comments = new ArrayList<>();

    public List<Comment> getAllComments() {
        return comments;
    }

    public Comment saveComment(Comment comment) {
        comments.add(comment);
        return comment;
    }
}
