package com.example.socialmedia.model;

import java.util.Date;

public class Post {
    private String id;
    private String caption;
    private String imageUrl;
    private boolean closeFriendsOnly;
    private Date createdAt;
    private String user;

    public Post() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public boolean isCloseFriendsOnly() {
        return closeFriendsOnly;
    }

    public void setCloseFriendsOnly(boolean closeFriendsOnly) {
        this.closeFriendsOnly = closeFriendsOnly;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
